//
//  ContentView.swift
//  NavigationSp24
//
//  Created by Janaka Balasooriya on 1/21/24.
//


import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    var url: URL
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        uiView.load(request)
    }
}

struct ContentView: View {
    @State private var path = NavigationPath()
    
    @State var dataFromSecond = ""
    @State var weight: String = ""
    @State var weightVal: Double = 0.0
    @State var moonWeight: Double = 0.0
    @State var calcJupiterWeight: Double = 0.0
    

    func calculateMoonWeight(weight: String) -> Double {
        guard let earth = Double(weight) else {
            return 0.0
        }
        return earth / 6.0
    }
    
    func calculateJupiterWeight(weight: String) -> Double {
        guard let earth = Double(weight) else {
            return 0.0
        }
        return earth * 2.4
    }
    
        var body: some View {
            
            NavigationStack(path: $path) {
                VStack{
                    Text("Welcome to Space Walk App")
                    Text(dataFromSecond)
                    
                    Text("You are on earth now")
                    HStack{Spacer()
                        Text("Enter your weight: " )
                        Spacer()
                        Spacer()
                        TextField("", text: $weight, onEditingChanged: { (changed) in
                            print("weight onEditingChanged - \(changed)")
                        })
                        .padding()
                        .foregroundColor(.blue)
                        .border(Color.black, width: 1)
                        Spacer()
                    }
                }
                                
                //List {
                    NavigationLink("Go to Moon", value: 2)
                    .padding()
                    .simultaneousGesture(TapGesture().onEnded {
                        dataFromSecond = "Coming from Earth"
                    })
               
                ScrollView(.horizontal) {
                    HStack{
                        let vid1 = URL(string: "https://www.youtube.com/embed/ZNIiewyOHSI?autoplay=1&controls=1")!
                        
                        WebView(url: vid1)
                            .frame(width: 168.75, height: 300)
                        
                        let vid2 = URL(string: "https://youtube.com/embed/3zJxc1jYkok?si=daHBwdP324Z_TOpG?autoplay=1&controls=1")!
                        
                        WebView(url: vid2)
                            .frame(width: 168.75, height: 300)
                        
                        let vid3 = URL(string: "https://youtube.com/embed/I-x1NnvfNxY?si=tAHVUd5BIwxCqeWU?autoplay=1&controls=1")!
                        
                        WebView(url: vid3)
                            .frame(width: 168.75, height: 300)
                        
                        let vid4 = URL(string: "https://youtube.com/embed/cgzGUQpIhyg?si=2utbwRpZ3t1RiE5a?autoplay=1&controls=1")!
                        
                        WebView(url: vid4)
                            .frame(width: 168.75, height: 300)
                        
                        
                    }
                }
                //}
                .navigationDestination(for: Int.self) { numberValue in
                    if numberValue == 2
                    {
                        let moonWeight = calculateMoonWeight(weight: weight)
                        SecondView(dataFromFirst: moonWeight, earthWeight: weight, dataSecond: $dataFromSecond, viewNumber: 2, path: $path) // $ = create binding so that when value changes, it reflects in content view ex: binds dataSecond with $dataFromSecond so that there value are shared
                        
                    }else
                    {
                        let moonWeight = calculateMoonWeight(weight: weight)
                        let calcJupiterWeight = calculateJupiterWeight(weight: weight)
                        ThirdView(fromData: moonWeight, path: $path, viewNumber: 3, earthWeight: weight, jupiterWeight: calcJupiterWeight, dataSecond: $dataFromSecond)
                    }
                    }
                }
                 .navigationTitle("ContentView")
                 .navigationBarTitleDisplayMode(.inline)
                
                 .onChange(of: dataFromSecond, initial: true) { oldVal, newVal in
                         print(newVal)
                         //dataFromSecond = "" // empty so that it can go to second view and check again
                     }// track whether dataFromSecond's value changes, update it to new value
            
                 
                
            }
        }


#Preview {
    ContentView()
}
