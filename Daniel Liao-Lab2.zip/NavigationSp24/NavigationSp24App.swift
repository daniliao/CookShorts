//
//  NavigationSp24App.swift
//  NavigationSp24
//
//  Created by Janaka Balasooriya on 1/21/24.
//

import SwiftUI

@main
struct NavigationSp24App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
